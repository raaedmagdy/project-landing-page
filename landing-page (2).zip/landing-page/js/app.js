// All section
let sections = document.querySelectorAll("section");

const menuBar = document.getElementById("navbar__list");

const fragment = document.createDocumentFragment();
// Create  nav
sections.forEach((section) => {
  let text = section.getAttribute("data-nav");

  let textNode = document.createTextNode(text);

  let sectionLink = document.createElement("a");
  sectionLink.style.color = "black";
  // make the nav dynamic and smooth
  sectionLink.addEventListener("click", function () {
    section.scrollIntoView({ behavior: "smooth" });
  });

  let newLi = document.createElement("li");

  sectionLink.appendChild(textNode);

  newLi.appendChild(sectionLink);

  fragment.appendChild(newLi);
});

// menuBar.appendChild(fragment);
menuBar.appendChild(fragment);
// active class
const links = document.querySelectorAll("a.menu__link")
window.addEventListener("scroll", e =>{
   // active class

sections.forEach((active_sec) => {

console.log(active_sec);

const rect = active_sec.getBoundingClientRect();
const text = active_sec.getAttribute("data-nav")
if (rect.top >= 0 && rect.top <=300) {
active_sec.classList.add("your-active-class");
 // toggle active class to the links
 links.forEach(link => {
         if(link.textContent === text) {
            link.classList.add("your-active-class");
         } else {
             link.classList.add("your-active-class");
         }
   })
   } else {
        active_sec.classList.remove("your-active-class");
       }
     })
})